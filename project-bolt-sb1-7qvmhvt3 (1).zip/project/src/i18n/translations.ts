export const translations = {
  en: {
    // Header & Navigation
    home: 'Home',
    contact: 'Contact Us',
    
    // Home Page
    heroTitle: 'Top  VPS & Hosting Providers That Accept Bitcoin',
    heroSubtitle: 'Compare prices, features, and regions for the best cryptocurrency-friendly hosting options',
    compareProviders: 'Compare Providers',
    filterByPrice: 'Filter by Price',
    filterByRegion: 'Filter by Region',
    priceRange: 'Price Range',
    allRegions: 'All Regions',
    northAmerica: 'North America',
    europe: 'Europe',
    asia: 'Asia',
    reset: 'Reset Filters',
    sortBy: 'Sort by',
    providerName: 'Provider Name',
    startingPrice: 'Starting Price',
    regions: 'Regions',
    cryptoPayments: 'Crypto Payments',
    features: 'Features',
    viewDetails: 'View Details',
    monthlyPricing: 'Monthly Pricing',
    bitcoinAccepted: 'Bitcoin Accepted',
    noProvidersFound: 'No providers match your current filters. Please try different criteria.',
    
    // Provider Details
    ram: 'RAM',
    cpu: 'CPU',
    storage: 'Storage',
    bandwidth: 'Bandwidth',
    datacenters: 'Datacenters',
    visitWebsite: 'Visit Website',
    
    // Contact Page
    contactTitle: 'Contact Us',
    contactSubtitle: 'Have questions about VPS providers or suggestions for our website? Send us a message!',
    yourName: 'Your Name',
    yourEmail: 'Your Email',
    subject: 'Subject',
    message: 'Message',
    send: 'Send Message',
    
    // Footer
    footerDescription: 'VPS-Bitcoin.site provides comparisons of top VPS, hosting and cloud providers that accept cryptocurrency payments.',
    quickLinks: 'Quick Links',
    contactUs: 'Contact Us',
    allRightsReserved: 'All Rights Reserved',
    
    // SEO
    metaDescription: 'Compare the top  VPS, hosting & cloud providers that accept Bitcoin and cryptocurrency payments. Filter by price and region.',
    metaKeywords: 'vps bitcoin, crypto hosting, bitcoin hosting, vps cryptocurrency, cloud bitcoin'
  },
  ru: {
    // Header & Navigation
    home: 'Главная',
    contact: 'Контакты',
    
    // Home Page
    heroTitle: 'Топ-20 VPS и хостинг-провайдеров, принимающих Биткоин',
    heroSubtitle: 'Сравните цены, функции и регионы для лучших вариантов хостинга, поддерживающих криптовалюту',
    compareProviders: 'Сравнить провайдеров',
    filterByPrice: 'Фильтр по цене',
    filterByRegion: 'Фильтр по региону',
    priceRange: 'Ценовой диапазон',
    allRegions: 'Все регионы',
    northAmerica: 'Северная Америка',
    europe: 'Европа',
    asia: 'Азия',
    reset: 'Сбросить фильтры',
    sortBy: 'Сортировать по',
    providerName: 'Название провайдера',
    startingPrice: 'Начальная цена',
    regions: 'Регионы',
    cryptoPayments: 'Крипто-платежи',
    features: 'Особенности',
    viewDetails: 'Подробнее',
    monthlyPricing: 'Ежемесячная стоимость',
    bitcoinAccepted: 'Принимается Биткоин',
    noProvidersFound: 'Нет провайдеров, соответствующих текущим фильтрам. Пожалуйста, попробуйте другие критерии.',
    
    // Provider Details
    ram: 'Оперативная память',
    cpu: 'Процессор',
    storage: 'Хранилище',
    bandwidth: 'Пропускная способность',
    datacenters: 'Дата-центры',
    visitWebsite: 'Посетить сайт',
    
    // Contact Page
    contactTitle: 'Свяжитесь с нами',
    contactSubtitle: 'У вас есть вопросы о VPS-провайдерах или предложения для нашего сайта? Отправьте нам сообщение!',
    yourName: 'Ваше имя',
    yourEmail: 'Ваш Email',
    subject: 'Тема',
    message: 'Сообщение',
    send: 'Отправить сообщение',
    
    // Footer
    footerDescription: 'VPS-Bitcoin.site предоставляет сравнение ведущих VPS, хостинг и облачных провайдеров, принимающих криптовалютные платежи.',
    quickLinks: 'Быстрые ссылки',
    contactUs: 'Связаться с нами',
    allRightsReserved: 'Все права защищены',
    
    // SEO
    metaDescription: 'Сравните топ-20 VPS, хостинг и облачных провайдеров, принимающих Биткоин и криптовалютные платежи. Фильтруйте по цене и региону.',
    metaKeywords: 'vps биткоин, крипто хостинг, биткоин хостинг, vps криптовалюта, облако биткоин'
  }
};