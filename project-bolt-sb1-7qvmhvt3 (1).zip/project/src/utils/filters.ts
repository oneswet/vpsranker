import { Provider, Filters } from '../types';

export const filterProviders = (providers: Provider[], filters: Filters): Provider[] => {
  return providers.filter(provider => {
    // Price filter
    const passesPrice = provider.startingPrice >= filters.price.min && 
                       provider.startingPrice <= filters.price.max;
    
    // Region filter
    const passesRegion = filters.regions.length === 0 || 
                         filters.regions.some(region => provider.regions.includes(region));
    
    return passesPrice && passesRegion;
  });
};

export const getMaxPrice = (providers: Provider[]): number => {
  return Math.ceil(Math.max(...providers.map(provider => provider.startingPrice)));
};