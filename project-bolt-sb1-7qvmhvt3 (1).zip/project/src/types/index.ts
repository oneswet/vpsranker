export interface Provider {
  id: number;
  name: string;
  logoUrl: string;
  startingPrice: number;
  regions: Region[];
  cryptoPayments: CryptoPayment[];
  features: string[];
  specs: {
    ram: string;
    cpu: string;
    storage: string;
    bandwidth: string;
  };
  datacenters: string[];
  website: string;
}

export type Region = 'northAmerica' | 'europe' | 'asia' | 'oceania' | 'southAmerica' | 'africa';

export type CryptoPayment = 'bitcoin' | 'ethereum' | 'litecoin' | 'monero' | 'usdt';

export interface PriceFilter {
  min: number;
  max: number;
}

export interface Filters {
  price: PriceFilter;
  regions: Region[];
}