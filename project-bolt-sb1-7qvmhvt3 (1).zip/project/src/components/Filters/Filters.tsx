import { useState, useEffect } from 'react';
import { Filters as FiltersType, Region } from '../../types';
import { useLanguage } from '../../context/LanguageContext';
import { translations } from '../../i18n/translations';

interface FiltersProps {
  filters: FiltersType;
  setFilters: (filters: FiltersType) => void;
  maxPrice: number;
}

const Filters: React.FC<FiltersProps> = ({ filters, setFilters, maxPrice }) => {
  const { language } = useLanguage();
  const t = translations[language];
  
  const [localPrice, setLocalPrice] = useState(filters.price);
  
  useEffect(() => {
    setLocalPrice(filters.price);
  }, [filters.price]);
  
  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    setLocalPrice({
      ...localPrice,
      max: value
    });
  };
  
  const handlePriceApply = () => {
    setFilters({
      ...filters,
      price: localPrice
    });
  };
  
  const handleRegionChange = (region: Region) => {
    let newRegions: Region[];
    
    if (region === 'northAmerica' && filters.regions.includes('northAmerica')) {
      newRegions = filters.regions.filter(r => r !== 'northAmerica');
    } else if (region === 'europe' && filters.regions.includes('europe')) {
      newRegions = filters.regions.filter(r => r !== 'europe');
    } else if (region === 'asia' && filters.regions.includes('asia')) {
      newRegions = filters.regions.filter(r => r !== 'asia');
    } else if (region === 'northAmerica') {
      newRegions = [...filters.regions, 'northAmerica'];
    } else if (region === 'europe') {
      newRegions = [...filters.regions, 'europe'];
    } else if (region === 'asia') {
      newRegions = [...filters.regions, 'asia'];
    } else {
      newRegions = filters.regions;
    }
    
    setFilters({
      ...filters,
      regions: newRegions
    });
  };
  
  const resetFilters = () => {
    setFilters({
      price: { min: 0, max: maxPrice },
      regions: []
    });
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">{t.filterByPrice}</h3>
        <div className="flex items-center">
          <span className="mr-2">${filters.price.min}</span>
          <div className="flex-1">
            <input 
              type="range" 
              min={filters.price.min} 
              max={maxPrice} 
              value={localPrice.max}
              onChange={handlePriceChange}
              onMouseUp={handlePriceApply}
              onTouchEnd={handlePriceApply}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
          </div>
          <span className="ml-2">${localPrice.max}</span>
        </div>
      </div>
      
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">{t.filterByRegion}</h3>
        <div className="space-y-2">
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="region-na" 
              checked={filters.regions.includes('northAmerica')}
              onChange={() => handleRegionChange('northAmerica')}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="region-na" className="ml-2 block text-sm text-gray-700">
              {t.northAmerica}
            </label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="region-eu" 
              checked={filters.regions.includes('europe')}
              onChange={() => handleRegionChange('europe')}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="region-eu" className="ml-2 block text-sm text-gray-700">
              {t.europe}
            </label>
          </div>
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="region-asia" 
              checked={filters.regions.includes('asia')}
              onChange={() => handleRegionChange('asia')}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label htmlFor="region-asia" className="ml-2 block text-sm text-gray-700">
              {t.asia}
            </label>
          </div>
        </div>
      </div>
      
      <button
        onClick={resetFilters}
        className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded transition-colors"
      >
        {t.reset}
      </button>
    </div>
  );
};

export default Filters;