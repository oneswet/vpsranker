import { Bitcoin, Mail, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext';
import { translations } from '../../i18n/translations';

const Footer = () => {
  const { language } = useLanguage();
  const t = translations[language];

  return (
    <footer className="bg-gray-900 text-white py-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Logo and Description */}
          <div>
            <div className="flex items-center mb-4">
              <Bitcoin className="h-6 w-6 text-yellow-500" />
              <span className="ml-2 font-bold text-lg">VPS-Bitcoin.site</span>
            </div>
            <p className="text-gray-300 text-sm">
              {t.footerDescription}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t.quickLinks}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-yellow-500 transition-colors">
                  {t.home}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-yellow-500 transition-colors">
                  {t.contact}
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t.contactUs}</h3>
            <div className="flex items-center mb-2">
              <Mail className="h-5 w-5 text-gray-400 mr-2" />
              <a href="mailto:top10ranke@gmail.com" className="text-gray-300 hover:text-yellow-500 transition-colors">
                top10ranke@gmail.com
              </a>
            </div>
            <div className="flex items-center">
              <Globe className="h-5 w-5 text-gray-400 mr-2" />
              <span className="text-gray-300">vps-bitcoin.site</span>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} VPS-Bitcoin.site. {t.allRightsReserved}
        </div>
      </div>
    </footer>
  );
};

export default Footer;