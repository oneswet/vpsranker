import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Bitcoin, Menu, X } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { translations } from '../../i18n/translations';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { language, setLanguage } = useLanguage();
  const t = translations[language];

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ru' : 'en');
  };

  return (
    <header 
      className={`sticky top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-gray-900 shadow-md' : 'bg-gray-900/95'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <Bitcoin className="h-8 w-8 text-yellow-500" />
            <span className="ml-2 text-white font-bold text-xl">VPS-Bitcoin.site</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-white hover:text-yellow-500 transition-colors">
              {t.home}
            </Link>
            <Link to="/contact" className="text-white hover:text-yellow-500 transition-colors">
              {t.contact}
            </Link>
            <button 
              onClick={toggleLanguage}
              className="px-3 py-1 bg-blue-700 hover:bg-blue-800 text-white rounded transition-colors"
            >
              {language === 'en' ? 'RU' : 'EN'}
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={toggleMenu} className="text-white">
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-gray-900 pb-4">
            <Link 
              to="/" 
              className="block py-2 text-white hover:text-yellow-500"
              onClick={() => setIsMenuOpen(false)}
            >
              {t.home}
            </Link>
            <Link 
              to="/contact" 
              className="block py-2 text-white hover:text-yellow-500"
              onClick={() => setIsMenuOpen(false)}
            >
              {t.contact}
            </Link>
            <button 
              onClick={toggleLanguage}
              className="mt-2 px-3 py-1 bg-blue-700 hover:bg-blue-800 text-white rounded transition-colors"
            >
              {language === 'en' ? 'RU' : 'EN'}
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;