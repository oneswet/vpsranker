import { useState } from 'react';
import { Bitcoin } from 'lucide-react';
import { Provider } from '../../types';
import { useLanguage } from '../../context/LanguageContext';
import { translations } from '../../i18n/translations';

interface ProviderCardProps {
  provider: Provider;
}

const ProviderCard: React.FC<ProviderCardProps> = ({ provider }) => {
  const [expanded, setExpanded] = useState(false);
  const { language } = useLanguage();
  const t = translations[language];
  
  const toggleExpanded = () => {
    setExpanded(!expanded);
  };
  
  const renderRegions = (provider: Provider) => {
    const regionMap: Record<string, string> = {
      northAmerica: language === 'en' ? 'North America' : 'Северная Америка',
      europe: language === 'en' ? 'Europe' : 'Европа',
      asia: language === 'en' ? 'Asia' : 'Азия',
      oceania: language === 'en' ? 'Oceania' : 'Океания',
      southAmerica: language === 'en' ? 'South America' : 'Южная Америка',
      africa: language === 'en' ? 'Africa' : 'Африка'
    };
    
    return provider.regions.map(region => regionMap[region]).join(', ');
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg border border-gray-200">
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold">{provider.name}</h3>
          <div className="flex items-center text-gray-600">
            <Bitcoin className="h-4 w-4 text-yellow-500 mr-1" />
            <span className="text-sm">{t.bitcoinAccepted}</span>
          </div>
        </div>
        
        <div className="flex flex-wrap -mx-2 mb-4">
          <div className="px-2 w-1/2">
            <div className="text-sm text-gray-600">{t.startingPrice}</div>
            <div className="font-semibold">${provider.startingPrice.toFixed(2)}/mo</div>
          </div>
          <div className="px-2 w-1/2">
            <div className="text-sm text-gray-600">{t.regions}</div>
            <div className="font-semibold truncate" title={renderRegions(provider)}>
              {renderRegions(provider)}
            </div>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="text-sm text-gray-600 mb-1">{t.features}</div>
          <div className="flex flex-wrap gap-1">
            {provider.features.slice(0, 3).map((feature, index) => (
              <span 
                key={index} 
                className="inline-block bg-gray-100 rounded-full px-2 py-1 text-xs"
              >
                {feature}
              </span>
            ))}
          </div>
        </div>
        
        <button
          onClick={toggleExpanded}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors"
        >
          {expanded ? t.viewDetails : t.viewDetails}
        </button>
      </div>
      
      {/* Expanded Details */}
      {expanded && (
        <div className="p-4 bg-gray-50 border-t border-gray-200">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <div className="text-sm text-gray-600">{t.ram}</div>
              <div className="font-semibold">{provider.specs.ram}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">{t.cpu}</div>
              <div className="font-semibold">{provider.specs.cpu}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">{t.storage}</div>
              <div className="font-semibold">{provider.specs.storage}</div>
            </div>
            <div>
              <div className="text-sm text-gray-600">{t.bandwidth}</div>
              <div className="font-semibold">{provider.specs.bandwidth}</div>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="text-sm text-gray-600 mb-1">{t.datacenters}</div>
            <div className="text-sm">
              {provider.datacenters.join(', ')}
            </div>
          </div>
          
          <a 
            href={provider.website} 
            target="_blank" 
            rel="noopener noreferrer"
            className="block w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded text-center transition-colors"
          >
            {t.visitWebsite}
          </a>
        </div>
      )}
    </div>
  );
};

export default ProviderCard;