import { Provider } from '../../types';
import ProviderCard from './ProviderCard';
import { useLanguage } from '../../context/LanguageContext';
import { translations } from '../../i18n/translations';

interface ProviderListProps {
  providers: Provider[];
}

const ProviderList: React.FC<ProviderListProps> = ({ providers }) => {
  const { language } = useLanguage();
  const t = translations[language];
  
  if (providers.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">{t.noProvidersFound}</p>
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {providers.map(provider => (
        <ProviderCard key={provider.id} provider={provider} />
      ))}
    </div>
  );
};

export default ProviderList;