import { Provider } from '../types';

export const providers: Provider[] = [
  {
    id: 1,
    name: "Vultr",
    logoUrl: "https://www.vultr.com/media/logo_ondark.svg",
    startingPrice: 3.50,
    regions: ['northAmerica', 'europe', 'asia', 'oceania'],
    cryptoPayments: ['bitcoin'],
    features: ['DDoS Protection', 'SSD Storage', '100% KVM'],
    specs: {
      ram: '512 MB',
      cpu: '1 vCPU',
      storage: '10 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['New York', 'Los Angeles', 'Amsterdam', 'Tokyo', 'Sydney'],
    website: 'https://www.vultr.com'
  },
  {
    id: 2,
    name: "Namecheap",
    logoUrl: "https://www.namecheap.com/assets/img/nc-logo/nc-logo.svg",
    startingPrice: 3.88,
    regions: ['northAmerica', 'europe'],
    cryptoPayments: ['bitcoin'],
    features: ['cPanel/WHM', 'Free Backups', 'Free Domain'],
    specs: {
      ram: '2 GB',
      cpu: '2 vCPU',
      storage: '20 GB SSD',
      bandwidth: 'Unmetered'
    },
    datacenters: ['Phoenix', 'Atlanta', 'Amsterdam', 'United Kingdom'],
    website: 'https://www.namecheap.com'
  },
  {
    id: 3,
    name: "HostSailor",
    logoUrl: "https://hostsailor.com/templates/hostsailor/img/logo.png",
    startingPrice: 4.99,
    regions: ['europe', 'asia'],
    cryptoPayments: ['bitcoin', 'ethereum', 'litecoin'],
    features: ['Instant Setup', 'DDoS Protection', 'Free IP'],
    specs: {
      ram: '1 GB',
      cpu: '1 vCPU',
      storage: '20 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['Netherlands', 'Romania', 'Dubai'],
    website: 'https://hostsailor.com'
  },
  {
    id: 4,
    name: "BuyVM",
    logoUrl: "https://buyvm.net/assets/img/header_logo.png",
    startingPrice: 2.00,
    regions: ['northAmerica', 'europe'],
    cryptoPayments: ['bitcoin'],
    features: ['DDoS Protection', 'Block Storage', 'Free Migration'],
    specs: {
      ram: '512 MB',
      cpu: '1 vCPU',
      storage: '10 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['Las Vegas', 'New York', 'Luxembourg'],
    website: 'https://buyvm.net'
  },
  {
    id: 5,
    name: "RamNode",
    logoUrl: "https://ramnode.com/static/images/logo.png",
    startingPrice: 3.00,
    regions: ['northAmerica', 'europe'],
    cryptoPayments: ['bitcoin', 'litecoin'],
    features: ['SSD Cached', 'SVZ Options', 'Instant Setup'],
    specs: {
      ram: '512 MB',
      cpu: '2 vCPU',
      storage: '15 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['Seattle', 'Atlanta', 'New York', 'Netherlands'],
    website: 'https://ramnode.com'
  },
  {
    id: 6,
    name: "Hostinger",
    logoUrl: "https://assets.hostinger.com/images/logo-homepage2020-f9c79137d7.svg",
    startingPrice: 3.95,
    regions: ['northAmerica', 'europe', 'asia', 'southAmerica'],
    cryptoPayments: ['bitcoin'],
    features: ['Free SSL', 'Daily Backups', 'DDoS Protection'],
    specs: {
      ram: '1 GB',
      cpu: '1 vCPU',
      storage: '20 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['USA', 'UK', 'Netherlands', 'Lithuania', 'Singapore', 'Brazil'],
    website: 'https://www.hostinger.com'
  },
  {
    id: 7,
    name: "Contabo",
    logoUrl: "https://contabo.com/img/contabo-logo.svg",
    startingPrice: 4.99,
    regions: ['europe', 'northAmerica'],
    cryptoPayments: ['bitcoin'],
    features: ['Free DDoS', 'High Memory', 'Snapshots'],
    specs: {
      ram: '4 GB',
      cpu: '4 vCPU',
      storage: '50 GB SSD',
      bandwidth: 'Unlimited'
    },
    datacenters: ['Germany', 'USA'],
    website: 'https://contabo.com'
  },
  {
    id: 8,
    name: "FastComet",
    logoUrl: "https://www.fastcomet.com/assets/images/fastcomet-logo.svg",
    startingPrice: 2.95,
    regions: ['northAmerica', 'europe', 'asia'],
    cryptoPayments: ['bitcoin'],
    features: ['Free SSL', 'Free CDN', 'Daily Backups'],
    specs: {
      ram: '2 GB',
      cpu: '2 vCPU',
      storage: '50 GB SSD',
      bandwidth: 'Unmetered'
    },
    datacenters: ['Chicago', 'Dallas', 'London', 'Frankfurt', 'Singapore', 'Tokyo'],
    website: 'https://www.fastcomet.com'
  },
  {
    id: 9,
    name: "AlphaVPS",
    logoUrl: "https://www.alphavps.com/assets/img/logo.png",
    startingPrice: 5.00,
    regions: ['europe', 'northAmerica'],
    cryptoPayments: ['bitcoin', 'ethereum'],
    features: ['Premium Network', 'KVM Virtualization', 'SSD Storage'],
    specs: {
      ram: '1 GB',
      cpu: '1 vCPU',
      storage: '25 GB SSD',
      bandwidth: '2 TB'
    },
    datacenters: ['Netherlands', 'Germany', 'USA'],
    website: 'https://www.alphavps.com'
  },
  {
    id: 10,
    name: "Linode",
    logoUrl: "https://www.linode.com/wp-content/uploads/2021/01/Linode-Logo-Black.svg",
    startingPrice: 5.00,
    regions: ['northAmerica', 'europe', 'asia', 'oceania'],
    cryptoPayments: ['bitcoin'],
    features: ['One-click apps', 'Node Balancers', 'API Access'],
    specs: {
      ram: '1 GB',
      cpu: '1 vCPU',
      storage: '25 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['Newark', 'Atlanta', 'London', 'Frankfurt', 'Singapore', 'Tokyo', 'Sydney'],
    website: 'https://www.linode.com'
  },
  {
    id: 11,
    name: "DigitalOcean",
    logoUrl: "https://www.digitalocean.com/assets/media/logos-badges/DO_Logo_horizontal_blue-1f9b35add0b5dcd3e25307286a9f0d42.svg",
    startingPrice: 5.00,
    regions: ['northAmerica', 'europe', 'asia'],
    cryptoPayments: ['bitcoin'],
    features: ['One-click apps', 'Team accounts', 'API Access'],
    specs: {
      ram: '1 GB',
      cpu: '1 vCPU',
      storage: '25 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['New York', 'San Francisco', 'Amsterdam', 'London', 'Frankfurt', 'Singapore', 'Bangalore'],
    website: 'https://www.digitalocean.com'
  },
  {
    id: 12,
    name: "Time4VPS",
    logoUrl: "https://www.time4vps.com/wp-content/themes/time4vps-theme/assets/images/logo.svg",
    startingPrice: 2.99,
    regions: ['europe'],
    cryptoPayments: ['bitcoin'],
    features: ['99.9% Uptime', 'IPv4 & IPv6', 'Instant Setup'],
    specs: {
      ram: '2 GB',
      cpu: '1 vCPU',
      storage: '20 GB SSD',
      bandwidth: '2 TB'
    },
    datacenters: ['Lithuania'],
    website: 'https://www.time4vps.com'
  },
  {
    id: 13,
    name: "Hetzner Cloud",
    logoUrl: "https://www.hetzner.com/assets/Uploads/home-top-logo.svg",
    startingPrice: 2.49,
    regions: ['europe'],
    cryptoPayments: ['bitcoin'],
    features: ['Snapshots', 'Floating IPs', 'Load Balancers'],
    specs: {
      ram: '2 GB',
      cpu: '1 vCPU',
      storage: '20 GB SSD',
      bandwidth: '20 TB'
    },
    datacenters: ['Germany', 'Finland'],
    website: 'https://www.hetzner.com/cloud'
  },
  {
    id: 14,
    name: "Kamatera",
    logoUrl: "https://www.kamatera.com/assets/img/kamatera-logo.svg",
    startingPrice: 4.00,
    regions: ['northAmerica', 'europe', 'asia'],
    cryptoPayments: ['bitcoin'],
    features: ['Full Root Access', 'Scalable Resources', 'High Availability'],
    specs: {
      ram: '1 GB',
      cpu: '1 vCPU',
      storage: '20 GB SSD',
      bandwidth: 'Unmetered'
    },
    datacenters: ['New York', 'Texas', 'Canada', 'London', 'Amsterdam', 'Frankfurt', 'Hong Kong', 'Israel'],
    website: 'https://www.kamatera.com'
  },
  {
    id: 15,
    name: "ChicagoVPS",
    logoUrl: "https://www.chicagovps.net/templates/chicagovps/images/logo.png",
    startingPrice: 4.95,
    regions: ['northAmerica'],
    cryptoPayments: ['bitcoin'],
    features: ['SolusVM Panel', 'Free Backups', 'DDoS Protection'],
    specs: {
      ram: '1 GB',
      cpu: '2 vCPU',
      storage: '20 GB SSD',
      bandwidth: '2 TB'
    },
    datacenters: ['Chicago', 'Buffalo', 'Dallas', 'Los Angeles'],
    website: 'https://www.chicagovps.net'
  },
  {
    id: 16,
    name: "CloudSigma",
    logoUrl: "https://www.cloudsigma.com/wp-content/uploads/2020/05/CloudSigma-1.png",
    startingPrice: 5.99,
    regions: ['northAmerica', 'europe', 'asia', 'oceania'],
    cryptoPayments: ['bitcoin'],
    features: ['Custom Sizing', 'Persistent Storage', 'Private Networking'],
    specs: {
      ram: '2 GB',
      cpu: '1 vCPU',
      storage: '50 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['Zurich', 'Geneva', 'Frankfurt', 'Washington DC', 'Manila', 'Perth', 'Saudi Arabia'],
    website: 'https://www.cloudsigma.com'
  },
  {
    id: 17,
    name: "OVHcloud",
    logoUrl: "https://www.ovhcloud.com/themes/ovh/images/brands/ovh/ovh.svg",
    startingPrice: 3.50,
    regions: ['europe', 'northAmerica', 'asia', 'oceania'],
    cryptoPayments: ['bitcoin'],
    features: ['Anti-DDoS', 'Public Cloud', 'Bare Metal'],
    specs: {
      ram: '2 GB',
      cpu: '1 vCPU',
      storage: '20 GB SSD',
      bandwidth: 'Unlimited'
    },
    datacenters: ['France', 'Germany', 'UK', 'Poland', 'Canada', 'Australia', 'Singapore'],
    website: 'https://www.ovhcloud.com'
  },
  {
    id: 18,
    name: "UpCloud",
    logoUrl: "https://upcloud.com/static/brand/upcloud-logo-white.svg",
    startingPrice: 5.00,
    regions: ['europe', 'northAmerica', 'asia'],
    cryptoPayments: ['bitcoin'],
    features: ['100% Uptime SLA', 'MaxIOPS Storage', 'High Availability'],
    specs: {
      ram: '1 GB',
      cpu: '1 vCPU',
      storage: '25 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['London', 'Amsterdam', 'Helsinki', 'Frankfurt', 'Chicago', 'San Jose', 'Singapore'],
    website: 'https://upcloud.com'
  },
  {
    id: 19,
    name: "BitLaunch",
    logoUrl: "https://bitlaunch.io/static/logo-dark-681cde0bb4f9a78efe85a94b4cd66c69.svg",
    startingPrice: 3.50,
    regions: ['northAmerica', 'europe', 'asia'],
    cryptoPayments: ['bitcoin', 'ethereum', 'litecoin', 'monero'],
    features: ['Anonymous Signup', 'Multiple Providers', 'Instant Deployment'],
    specs: {
      ram: '1 GB',
      cpu: '1 vCPU',
      storage: '25 GB SSD',
      bandwidth: '1 TB'
    },
    datacenters: ['New York', 'Amsterdam', 'London', 'Frankfurt', 'Singapore'],
    website: 'https://bitlaunch.io'
  },
  {
    id: 20, 
    name: "HostHatch",
    logoUrl: "https://hosthatch.com/assets/img/logo.svg",
    startingPrice: 2.00,
    regions: ['northAmerica', 'europe', 'asia'],
    cryptoPayments: ['bitcoin', 'ethereum'],
    features: ['NVMe Storage', 'Snapshots', 'API Access'],
    specs: {
      ram: '512 MB',
      cpu: '1 vCPU',
      storage: '10 GB NVMe',
      bandwidth: '2 TB'
    },
    datacenters: ['Los Angeles', 'New York', 'Stockholm', 'Amsterdam', 'Singapore'],
    website: 'https://hosthatch.com'
  }
];