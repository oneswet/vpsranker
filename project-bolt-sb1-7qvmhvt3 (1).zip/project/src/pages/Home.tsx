import { useState, useEffect } from 'react';
import { Bitcoin } from 'lucide-react';
import Filters from '../components/Filters/Filters';
import ProviderList from '../components/ProviderList/ProviderList';
import { providers } from '../data/providers';
import { filterProviders, getMaxPrice } from '../utils/filters';
import { Filters as FiltersType } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { translations } from '../i18n/translations';

const Home = () => {
  const { language } = useLanguage();
  const t = translations[language];
  const maxPrice = getMaxPrice(providers);
  
  const [filters, setFilters] = useState<FiltersType>({
    price: { min: 0, max: maxPrice },
    regions: []
  });
  
  const [filteredProviders, setFilteredProviders] = useState(providers);
  
  // Update filtered providers when filters change
  useEffect(() => {
    setFilteredProviders(filterProviders(providers, filters));
  }, [filters]);
  
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-12 px-4 rounded-lg mb-8">
        <div className="max-w-4xl mx-auto text-center">
          <Bitcoin className="h-16 w-16 mx-auto mb-4 text-yellow-500" />
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t.heroTitle}</h1>
          <p className="text-lg text-gray-300 mb-8">{t.heroSubtitle}</p>
          <a 
            href="#providers" 
            className="inline-block bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold py-3 px-6 rounded-lg transition-colors"
          >
            {t.compareProviders}
          </a>
        </div>
      </section>
      
      <div id="providers" className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Filters - Left Sidebar */}
        <div className="lg:col-span-1">
          <Filters 
            filters={filters} 
            setFilters={setFilters} 
            maxPrice={maxPrice}
          />
        </div>
        
        {/* Provider List - Main Content */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow-md p-4 mb-6">
            <h2 className="text-xl font-bold mb-2">{filteredProviders.length} VPS {t.providerName}</h2>
            <p className="text-gray-600">{t.monthlyPricing}</p>
          </div>
          
          <ProviderList providers={filteredProviders} />
        </div>
      </div>
    </div>
  );
};

export default Home;